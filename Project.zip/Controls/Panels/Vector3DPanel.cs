﻿using Project.Controls.Inputs;
using Project.Geometry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.Controls.Panels;
public partial class Vector3DPanel : BasePanel {
	public Vector3D CenterValue { get => this.Vector3DInput.Value; set => this.Vector3DInput.Value = value; }

	public override event EventHandler? ValueChanged { add => this.Vector3DInput.ValueChanged += value; remove => this.Vector3DInput.ValueChanged -= value; }

	public Vector3DPanel() {
		InitializeComponent();
	}
}
