﻿using Project.Geometry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.Controls.Panels;
public partial class Vector2DPanel : BasePanel {
	public Vector2D CenterValue { get => this.Vector2DInput.Value; set => this.Vector2DInput.Value = value; }

	public override event EventHandler? ValueChanged { add => this.Vector2DInput.ValueChanged += value; remove => this.Vector2DInput.ValueChanged -= value; }

	public Vector2DPanel() {
		InitializeComponent();
	}
}
