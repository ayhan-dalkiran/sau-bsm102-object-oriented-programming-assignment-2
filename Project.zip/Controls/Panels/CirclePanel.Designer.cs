﻿namespace Project.Controls.Panels;

partial class CirclePanel {
	/// <summary> 
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.IContainer components = null;

	/// <summary> 
	/// Clean up any resources being used.
	/// </summary>
	/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	protected override void Dispose(bool disposing) {
		if (disposing && (components != null)) {
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	#region Component Designer generated code

	/// <summary> 
	/// Required method for Designer support - do not modify 
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent() {
		this.CenterInput = new Inputs.Vector2DInput();
		this.RadiusInput = new Inputs.FloatInput();
		this.SuspendLayout();
		// 
		// ObjectNameInput
		// 
		this.ObjectNameInput.Location = new System.Drawing.Point(3, 70);
		// 
		// DeleteButton
		// 
		this.DeleteButton.Location = new System.Drawing.Point(3, 105);
		// 
		// ColorButton
		// 
		this.ColorButton.Location = new System.Drawing.Point(84, 105);
		// 
		// SelectedColorPanel
		// 
		this.SelectedColorPanel.Location = new System.Drawing.Point(165, 105);
		// 
		// CenterInput
		// 
		this.CenterInput.AutoSize = true;
		this.CenterInput.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
		this.CenterInput.InputName = "Merkez:";
		this.CenterInput.Location = new System.Drawing.Point(3, 3);
		this.CenterInput.MaximumX = new decimal(new int[] { -1, -1, -1, 0 });
		this.CenterInput.MaximumY = new decimal(new int[] { -1, -1, -1, 0 });
		this.CenterInput.MinimumX = new decimal(new int[] { -1, -1, -1, int.MinValue });
		this.CenterInput.MinimumY = new decimal(new int[] { -1, -1, -1, int.MinValue });
		this.CenterInput.Name = "CenterInput";
		this.CenterInput.Size = new System.Drawing.Size(312, 29);
		this.CenterInput.TabIndex = 2;
		this.CenterInput.XLabelText = "X:";
		this.CenterInput.YLabelText = "Y:";
		// 
		// RadiusInput
		// 
		this.RadiusInput.AutoSize = true;
		this.RadiusInput.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
		this.RadiusInput.InputName = "Yarıçap:";
		this.RadiusInput.Location = new System.Drawing.Point(3, 38);
		this.RadiusInput.MaxValue = new decimal(new int[] { -1, -1, -1, 0 });
		this.RadiusInput.MinValue = new decimal(new int[] { 0, 0, 0, 0 });
		this.RadiusInput.Name = "RadiusInput";
		this.RadiusInput.Size = new System.Drawing.Size(160, 29);
		this.RadiusInput.TabIndex = 3;
		this.RadiusInput.Value = 0F;
		// 
		// CirclePanel
		// 
		this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
		this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.Controls.Add(this.CenterInput);
		this.Controls.Add(this.RadiusInput);
		this.Name = "CirclePanel";
		this.Size = new System.Drawing.Size(318, 131);
		this.Controls.SetChildIndex(this.ColorButton, 0);
		this.Controls.SetChildIndex(this.SelectedColorPanel, 0);
		this.Controls.SetChildIndex(this.RadiusInput, 0);
		this.Controls.SetChildIndex(this.CenterInput, 0);
		this.Controls.SetChildIndex(this.ObjectNameInput, 0);
		this.Controls.SetChildIndex(this.DeleteButton, 0);
		this.ResumeLayout(false);
		this.PerformLayout();
	}

	#endregion

	private Inputs.Vector2DInput CenterInput;
	private Inputs.FloatInput RadiusInput;
}
