﻿using System;
using System.ComponentModel;
using Project.Geometry;

namespace Project.Controls.Panels;
public partial class RectangularPrismPanel : BasePanel {
	public Vector3D CenterValue { get => this.CenterInput.Value; set => this.CenterInput.Value = value; }
	public Vector3D SizeValue { get => this.SizeInput.Value; set => this.SizeInput.Value = value; }

	public override event EventHandler? ValueChanged {
		add {
			this.CenterInput.ValueChanged += value;
			this.SizeInput.ValueChanged += value;
		}
		remove {
			this.CenterInput.ValueChanged -= value;
			this.SizeInput.ValueChanged -= value;
		}
	}

	public RectangularPrismPanel() {
		InitializeComponent();
	}
}
