using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Windows.Forms;

using Project.Controls.Panels;
using Project.Geometry;

namespace Project;
public partial class MainForm : Form {
	public MainForm() {
		InitializeComponent();
	}
}
