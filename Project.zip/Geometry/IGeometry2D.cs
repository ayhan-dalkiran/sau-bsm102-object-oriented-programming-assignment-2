﻿namespace Project.Geometry;
public interface IGeometry2D : IDrawable {
	public Vector2D Center { get; }
}
