﻿using System.Drawing;

namespace Project.Geometry;
public abstract class Shape : IDrawable {
	public abstract PointF VP_Point { get; }
	public abstract SizeF VP_Size { get; }
	public Color VP_Color { get; set; } = Color.Gray;
	public abstract float VP_ZIndex { get; }
}
