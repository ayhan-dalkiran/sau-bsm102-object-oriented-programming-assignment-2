﻿using System.Drawing;

namespace Project.Geometry;
public interface IDrawable {
	public PointF VP_Point { get; }
	public SizeF VP_Size { get; }
	public float VP_ZIndex { get; }
	public Color VP_Color { get; }
}
