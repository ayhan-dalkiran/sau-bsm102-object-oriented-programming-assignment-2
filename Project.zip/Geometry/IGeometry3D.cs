﻿namespace Project.Geometry;
public interface IGeometry3D : IDrawable {
	public Vector3D Center { get; }
}
